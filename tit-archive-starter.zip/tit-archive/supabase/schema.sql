-- Tít. — initial Supabase schema
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique,
  display_name text,
  avatar_url text,
  role text not null default 'reader' check (role in ('reader','admin')),
  created_at timestamptz not null default now()
);

create table if not exists public.stories (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null,
  title text not null,
  summary text not null default '',
  cover_url text,
  fandom text,
  pairing text,
  rating text not null default 'General',
  status text not null default 'ongoing' check (status in ('ongoing','completed','hiatus')),
  is_published boolean not null default false,
  published_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.chapters (
  id uuid primary key default gen_random_uuid(),
  story_id uuid not null references public.stories(id) on delete cascade,
  chapter_number integer not null,
  title text not null,
  content_json jsonb not null default '{}'::jsonb,
  content_html text not null default '',
  is_published boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(story_id, chapter_number)
);

create table if not exists public.tags (
  id uuid primary key default gen_random_uuid(),
  name text unique not null,
  category text not null default 'other'
);
create table if not exists public.story_tags (
  story_id uuid not null references public.stories(id) on delete cascade,
  tag_id uuid not null references public.tags(id) on delete cascade,
  primary key(story_id, tag_id)
);
create table if not exists public.bookmarks (
  user_id uuid not null references public.profiles(id) on delete cascade,
  story_id uuid not null references public.stories(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(user_id, story_id)
);
create table if not exists public.reading_progress (
  user_id uuid not null references public.profiles(id) on delete cascade,
  story_id uuid not null references public.stories(id) on delete cascade,
  chapter_id uuid references public.chapters(id) on delete set null,
  updated_at timestamptz not null default now(),
  primary key(user_id, story_id)
);
create table if not exists public.comments (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  story_id uuid not null references public.stories(id) on delete cascade,
  chapter_id uuid references public.chapters(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 5000),
  is_hidden boolean not null default false,
  created_at timestamptz not null default now()
);

-- Enable RLS on every user-facing table.
alter table public.profiles enable row level security;
alter table public.stories enable row level security;
alter table public.chapters enable row level security;
alter table public.tags enable row level security;
alter table public.story_tags enable row level security;
alter table public.bookmarks enable row level security;
alter table public.reading_progress enable row level security;
alter table public.comments enable row level security;

-- Public can read published works only.
create policy "public reads published stories" on public.stories for select using (is_published = true);
create policy "public reads published chapters" on public.chapters for select using (is_published = true and exists (select 1 from public.stories s where s.id = story_id and s.is_published = true));
create policy "public reads tags" on public.tags for select using (true);
create policy "public reads story tags" on public.story_tags for select using (exists (select 1 from public.stories s where s.id = story_id and s.is_published = true));
create policy "users read own profile" on public.profiles for select to authenticated using (auth.uid() = id);
-- Profile updates are intentionally not enabled in this starter schema. Add a safe column-scoped update path later; never let readers change profiles.role.
create policy "users manage own bookmarks" on public.bookmarks for all to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "users manage own reading progress" on public.reading_progress for all to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "users read visible comments" on public.comments for select using (is_hidden = false);
create policy "users create own comments" on public.comments for insert to authenticated with check (auth.uid() = user_id);
create policy "users delete own comments" on public.comments for delete to authenticated using (auth.uid() = user_id);

-- IMPORTANT: Do not grant admin by allowing users to edit profiles.role.
-- Set the first admin role manually in Supabase SQL editor after creating your account.
-- Example (replace with your auth user UUID):
-- update public.profiles set role = 'admin' where id = 'YOUR-USER-UUID';
