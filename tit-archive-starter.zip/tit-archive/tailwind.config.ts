import type { Config } from 'tailwindcss';
const config: Config = { content: ['./app/**/*.{js,ts,jsx,tsx,mdx}','./components/**/*.{js,ts,jsx,tsx,mdx}'], theme: { extend: { colors: { cocoa: '#38251F', chocolate: '#654638', caramel: '#B8875D', cream: '#F4EBDD', milk: '#FFF9F0', muted: '#8A7568' }, fontFamily: { display: ['Georgia','serif'], body: ['Arial','sans-serif'] } } }, plugins: [] };
export default config;
