import Link from 'next/link';

export default function Header() {
  return <header className="site-header"><Link href="/" className="wordmark">Tít<span>.</span></Link><nav aria-label="Điều hướng chính"><Link href="/archive">Kho truyện</Link><a href="/#series">Series</a><a href="/#about">Giới thiệu</a></nav><Link href="/admin" className="header-action">Quản trị <span>↗</span></Link></header>;
}
