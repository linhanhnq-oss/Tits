'use client';
import { useEditor, EditorContent } from '@tiptap/react';
import StarterKit from '@tiptap/starter-kit';
import Placeholder from '@tiptap/extension-placeholder';

export default function RichTextEditor(){
 const editor=useEditor({ extensions:[StarterKit,Placeholder.configure({placeholder:'Bắt đầu viết câu chuyện của bạn…'})], content:'<p></p>', immediatelyRender:false, editorProps:{attributes:{class:'prose-editor'}} });
 if(!editor) return <div className="editor-loading">Đang mở trình soạn thảo…</div>;
 const controls=[['B','bold',()=>editor.chain().focus().toggleBold().run()],['I','italic',()=>editor.chain().focus().toggleItalic().run()],['H2','heading',()=>editor.chain().focus().toggleHeading({level:2}).run()],['❝','blockquote',()=>editor.chain().focus().toggleBlockquote().run()],['•','bullet',()=>editor.chain().focus().toggleBulletList().run()],['1.','ordered',()=>editor.chain().focus().toggleOrderedList().run()]] as const;
 return <div className="rich-editor"><div className="editor-toolbar">{controls.map(([label,key,action])=><button type="button" key={key} onClick={action} className={key==='heading'?editor.isActive('heading')?'active':'':editor.isActive(key)?'active':''} aria-label={key}>{label}</button>)}<button type="button" onClick={()=>editor.chain().focus().undo().run()}>↶</button><button type="button" onClick={()=>editor.chain().focus().redo().run()}>↷</button></div><EditorContent editor={editor}/><div className="editor-hint">Trình soạn thảo thử nghiệm · Nội dung chưa được lưu vào database.</div></div>;
}
