import Link from 'next/link';
import type { Story } from '@/lib/data';

export default function StoryCard({ story, index }: { story: Story; index: number }) {
  return <article className="story-card"><Link href={`/story/${story.slug}`} className="cover" style={{background: story.accent}}><span className="cover-number">TÍT. / {String(index + 1).padStart(2,'0')}</span><span className="cover-title">{story.title}</span><span className="cover-bottom">A STORY TO KEEP</span></Link><div className="story-meta"><div className="eyebrow">{story.fandom} · {story.rating}</div><h3><Link href={`/story/${story.slug}`}>{story.title}</Link></h3><p className="pairing">{story.pairing}</p><p className="summary">{story.summary}</p><div className="tag-row">{story.tags.slice(0,3).map(tag=><span key={tag}>{tag}</span>)}</div><div className="story-foot"><span>{story.chapters} chương · {story.words} từ</span><span>{story.status}</span></div></div></article>;
}
