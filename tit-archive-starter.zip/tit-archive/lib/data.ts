export type Story = {
  slug: string; title: string; pairing: string; fandom: string; summary: string;
  rating: string; status: 'Đang tiến hành' | 'Hoàn thành' | 'Tạm ngưng';
  tags: string[]; chapters: number; words: string; updated: string; accent: string;
};

export const stories: Story[] = [
  { slug:'mot-noi-de-tro-ve', title:'Một nơi để trở về', pairing:'Moon Hyeonjoon / Lee Minhyeong', fandom:'League of Legends', summary:'Có những người đi qua đời nhau như một cơn mưa. Cũng có người ở lại, dịu dàng hong khô những ngày ẩm ướt.', rating:'Teen', status:'Đang tiến hành', tags:['Romance','Healing','Modern AU'], chapters:4, words:'8.2k', updated:'31.10.2026', accent:'#D9BDA5' },
  { slug:'mua-di-qua-thanh-pho', title:'Mưa đi qua thành phố', pairing:'Ryu Minseok / Moon Hyeonjoon', fandom:'League of Legends', summary:'Thành phố vẫn đông đúc như mọi ngày, chỉ có một người bỗng thấy lòng mình vắng đi.', rating:'General', status:'Hoàn thành', tags:['Angst','Slice of Life'], chapters:1, words:'3.1k', updated:'24.10.2026', accent:'#B7A69B' },
  { slug:'nhung-ngay-thang-tu', title:'Những ngày tháng tư', pairing:'Choi Wooje / Moon Hyeonjoon', fandom:'League of Legends', summary:'Một câu chuyện nhỏ về tuổi trẻ, những điều chưa kịp nói và mùa xuân ở lại rất lâu.', rating:'Teen', status:'Đang tiến hành', tags:['Fluff','Coming of Age'], chapters:2, words:'5.6k', updated:'19.10.2026', accent:'#C9B49B' }
];
