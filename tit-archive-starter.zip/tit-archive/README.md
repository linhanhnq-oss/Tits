# Tít. — vương quốc chocolate

Starter project for a personal Vietnamese fanfiction archive.

## What's included
- Next.js App Router + TypeScript + Tailwind CSS
- Chocolate / cream visual direction
- Homepage, archive search + status filter, story detail, admin placeholder
- Sample story data (replace with your own)
- Supabase client placeholder and initial SQL schema

## Requirements
- Node.js 20.9 or newer
- npm

## Run locally
1. Extract this folder.
2. Open a terminal in the `tit-archive` folder.
3. Run `npm install`.
4. Run `npm run dev`.
5. Open http://localhost:3000.

## Connect Supabase later
1. Create a project at https://supabase.com.
2. Copy `.env.example` to `.env.local`.
3. Add the Project URL and anon/publishable key.
4. Run `supabase/schema.sql` in the Supabase SQL Editor.
5. Configure profile creation and admin assignment before making admin features public.

## Important status
This is the first UI + project scaffold, not a production-ready archive yet. Stories are currently sample data in `lib/data.ts`. Authentication, real rich-text publishing, comments, bookmarks, reader preferences and real read statistics are not wired up yet. The `/admin` page is only a placeholder and must not be exposed publicly as a functioning admin area until authentication and server-side authorization/RLS are implemented.

## Next build steps
1. Add Supabase sign-up/sign-in and profile creation.
2. Add server-side admin authorization and safe admin role management.
3. Build the Tiptap rich-text chapter editor and publishing workflow.
4. Load stories/chapters from Supabase instead of sample data.
5. Add tags, bookmarks, comments, reading progress and privacy-conscious read analytics.
