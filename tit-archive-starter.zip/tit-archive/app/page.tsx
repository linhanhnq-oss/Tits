import Link from 'next/link';
import StoryCard from '@/components/StoryCard';
import { stories } from '@/lib/data';

export default function Home() {
  return <main><section className="hero"><div className="hero-inner"><div className="eyebrow">WELCOME TO TÍT'S LITTLE WORLD</div><h1>vương quốc<br/>chocolate.</h1><p>Một góc nhỏ dành cho những câu chuyện. Nơi mỗi nhân vật, mỗi mối duyên và mỗi thế giới đều có một chỗ để ở lại.</p><div className="hero-links"><Link className="button-primary" href="/archive">Khám phá kho truyện ↗</Link><a className="button-outline" href="#about">Về Tít</a></div></div></section>
    <section className="section"><div className="section-heading"><div><div className="eyebrow">A LITTLE SOMETHING TO READ</div><h2>Những câu chuyện</h2></div><Link className="text-link" href="/archive">Xem toàn bộ archive ↗</Link></div><div className="story-grid">{stories.map((story,i)=><StoryCard key={story.slug} story={story} index={i}/>)}</div></section>
    <section className="about-band" id="about"><div><div className="eyebrow">A NOTE FROM THE ARCHIVIST</div><h2>Chào mừng đến với Tít.</h2></div><p>Đây là thư viện fanfiction cá nhân, nơi những câu chuyện được sắp xếp, lưu giữ và tìm thấy nhau. Hãy thong thả dạo quanh, chọn một câu chuyện và ở lại lâu thêm một chút.</p></section>
    <section className="section" id="series"><div className="eyebrow">COLLECTED WORLDS</div><h2 style={{fontFamily:'Georgia,serif',fontWeight:500,fontSize:42,margin:'12px 0'}}>Một thế giới, nhiều câu chuyện.</h2><p className="page-intro">Các series sẽ được tập hợp tại đây khi bạn bắt đầu xây dựng những bộ truyện của riêng mình.</p><Link className="text-link" href="/archive">Bắt đầu khám phá ↗</Link></section></main>;
}
