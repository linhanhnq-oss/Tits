'use client';
import { useMemo, useState } from 'react';
import StoryCard from '@/components/StoryCard';
import { stories } from '@/lib/data';

export default function ArchivePage(){
 const [query,setQuery]=useState(''); const [status,setStatus]=useState('Tất cả trạng thái');
 const filtered=useMemo(()=>stories.filter(s=>(`${s.title} ${s.pairing} ${s.fandom} ${s.tags.join(' ')}`).toLowerCase().includes(query.toLowerCase())&&(status==='Tất cả trạng thái'||s.status===status)),[query,status]);
 return <main className="page-wrap"><div className="eyebrow">THE COLLECTION</div><h1 className="page-title">Kho truyện</h1><p className="page-intro">Tìm một câu chuyện theo tên fic, pairing, fandom hoặc tag. Cứ thong thả, có thể bạn sẽ tìm thấy điều mình chưa biết là đang kiếm tìm.</p><div className="archive-tools"><input className="search-input" value={query} onChange={e=>setQuery(e.target.value)} placeholder="Tìm fic, pairing, fandom, tag..." aria-label="Tìm kiếm truyện"/><select className="select-input" value={status} onChange={e=>setStatus(e.target.value)}><option>Tất cả trạng thái</option><option>Đang tiến hành</option><option>Hoàn thành</option><option>Tạm ngưng</option></select></div><p className="eyebrow">{filtered.length} TÁC PHẨM</p>{filtered.length?<div className="story-grid">{filtered.map((story,i)=><StoryCard key={story.slug} story={story} index={i}/>)}</div>:<div className="empty-state">Không tìm thấy tác phẩm phù hợp. Thử từ khóa khác nhé.</div>}</main>
}
