import type { Metadata } from 'next';
import './globals.css';
import Header from '@/components/Header';

export const metadata: Metadata = { title: 'Tít. — vương quốc chocolate', description: 'Một nơi để những câu chuyện được lưu giữ.' };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="vi"><body><Header />{children}<footer className="site-footer"><div><div className="wordmark">Tít<span>.</span></div><small>VƯƠNG QUỐC CHOCOLATE</small></div><small>MADE WITH STORIES & A LITTLE CHOCOLATE.</small></footer></body></html>;
}
